import pandas as pd
import sys, os, os.path
import numpy as np
from sklearn.metrics import f1_score
from glob import glob

###USEFUL FUNCTION
def ls(filename):
	return sorted(glob(filename))

def mkdir(d):
	if not os.path.exists(d):
		os.makedirs(d)

if (os.name == "nt"):
	filesep = '\\'
else:
	filesep = '/'

def read_content_solution(filename):
	solution = []
	f = open(filename, 'r')
	while True:
		# Get next line from file
		text = f.readline()
		print(text)
		# if line is empty
		# end of file is reached
		if not text:
			break
		text = text.replace('\n', '')
		text = text.split(" ")
		print(text)
		if text[2] == '"Fake"':
			solution.append(1)
		else:
			solution.append(0)
	print(solution)
	return solution

def load_categories():
	print("Load Categories function")
	url = "https://github.com/jpposadas/FakeNewsCorpusSpanish/blob/master/development.xlsx?raw=true"
	df = pd.read_excel(url)
	df = df[['Id', 'Category']]
	category = list(df['Category'])
	classification = []
	for c in category:
		if c=='True':
			classification.append(0)
		else:
			classification.append(1)

	df['Clasification'] = classification
	print("Load True Values", classification)
	return classification

input_dir = sys.argv[1]
output_dir = sys.argv[2]

print("input_dir: ", input_dir)
print("output_dir: ", output_dir)

submit_dir = os.path.join(input_dir, 'res') 
truth_dir = os.path.join(input_dir, 'ref')

print("submit_dir: ", submit_dir)
print("truth_dir: ", truth_dir)


if not os.path.isdir(submit_dir):
	print("{} doesn't exist".format(submit_dir))

if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
	if not os.path.exists(output_dir):
		os.makedirs(output_dir)

	output_filename = os.path.join(output_dir, 'scores.txt')              
	output_file = open(output_filename, 'w')

	solution_names = sorted(ls(os.path.join(input_dir, 'res', '*.txt')))
	
	print("solution names:", solution_names)

	for i, solution_file in enumerate(solution_names):
		print("solution_file", solution_file)
		
		# Read the solution and prediction values into numpy arrays
		solution = read_content_solution(solution_file)
		prediction = load_categories()

		if len(solution) != len(prediction): raise ValueError(
			"Bad prediction shape {}".format(prediction.shape))
		
		f1_score_value = f1_score(solution, prediction)
		print(f1_score_value)
		output_file.write("F1: %0.4f\n" % f1_score_value)
	output_file.close()

	
